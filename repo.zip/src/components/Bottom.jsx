import React, { Component } from 'react'
import { Jumbotron, Grid, Row, Col } from 'react-bootstrap';
import './bootom.css';
 
class Bottom extends React.Component{

  render() {
      return (
        <div className="show-grid text-center fo">
        <div className="container"> zdczf</div>
        </div>
             
      )
  }

}

export default Bottom;